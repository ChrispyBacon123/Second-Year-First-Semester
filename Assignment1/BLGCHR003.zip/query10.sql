SELECT SUM(quantityInStock) AS total
FROM products;