SELECT phone
FROM offices
WHERE country = "USA" OR country = "UK";
