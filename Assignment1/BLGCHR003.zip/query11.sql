SELECT AVG(quantityInStock) AS mean
FROM products;