SELECT DISTINCT country 
FROM customers;