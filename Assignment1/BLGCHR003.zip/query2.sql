Select * FROM orderdetails
LIMIT 1;