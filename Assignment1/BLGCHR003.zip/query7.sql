SELECT productCode
FROM products
WHERE productCode LIKE "S%" AND productCode LIKE "____\_%" ;